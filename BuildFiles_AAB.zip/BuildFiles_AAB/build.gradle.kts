﻿plugins {
    kotlin("android") version "1.9.10"
    kotlin("plugin.serialization") version "1.9.10"
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
