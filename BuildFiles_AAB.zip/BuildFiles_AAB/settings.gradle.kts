﻿rootProject.name = "AdForge_Android3"
